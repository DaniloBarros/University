//
//  Computer.hpp
//  Assignment8
//
//  Created by Danilo Mendes on 4/17/16.
//  Copyright © 2016 Danilo Mendes. All rights reserved.
//

#ifndef Computer_hpp
#define Computer_hpp

class Printer;
class Smartphone;

#include "DeviceOS.hpp"

using namespace std;

class Computer : public DeviceOS {
    
    vector<Smartphone> smartphones;
    vector<Printer> printers;
    
public:
    Computer():DeviceOS(){};
    Computer(string name, vector<File> docs):DeviceOS(name,docs){};
    
    vector<Smartphone> getSmartphones(){return smartphones;};
    vector<Printer> getPrinters(){return printers;};
    
    bool installSmartphone(Smartphone cell);
    bool desinstallSmartphone();
    bool sync(Smartphone cel);
    bool print(Printer printer, File file);
};

#endif /* Computer_hpp */
