//
//  Printer.hpp
//  Assignment8
//
//  Created by Danilo Mendes on 4/17/16.
//  Copyright © 2016 Danilo Mendes. All rights reserved.
//

#ifndef Printer_hpp
#define Printer_hpp

class File;

class Printer{
    bool installed;
    
public:
    
    File scan();
    bool print(File doc);
};

#endif /* Printer_hpp */
