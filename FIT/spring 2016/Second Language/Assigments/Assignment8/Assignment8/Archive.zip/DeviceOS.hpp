//
//  DeviceOS.hpp
//  Assignment8
//
//  Created by Danilo Mendes on 4/17/16.
//  Copyright © 2016 Danilo Mendes. All rights reserved.
//

#ifndef DeviceOS_hpp
#define DeviceOS_hpp

#include <iostream>
#include <vector>
#include "File.hpp"

using namespace std;

class DeviceOS {
    
    string name;
    static int id; // = 0 on .cpp
    
    vector<File> documents;
    string configFilePath;
    
public:
    DeviceOS(){name = ""; id++; configFilePath="";};
    DeviceOS(string name):name(name){id++; configFilePath="";};
    DeviceOS(string name, vector<File> doc):name(name),documents(doc){id++;};
    DeviceOS(string name, vector<File> docs, string path):DeviceOS(name,docs){
        configFilePath=path;
    };
    
    string getName(){return name;}
    int getId(){return id;}
    vector<File> getDocuments(){return documents;}
    
    void setName(string newName){name = newName;}
    void setDocuments(vector<File> doc){documents = move(doc);}
    
    void getSettings();
    void updateSettings(ostringstream ss);
    
};


#endif /* DeviceOS_hpp */
