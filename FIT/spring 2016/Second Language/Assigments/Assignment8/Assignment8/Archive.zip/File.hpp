//
//  File.hpp
//  Assignment8
//
//  Created by Danilo Mendes on 4/17/16.
//  Copyright © 2016 Danilo Mendes. All rights reserved.
//

#ifndef File_hpp
#define File_hpp

#include <iostream>

using namespace std;

class File {
    string name;
    string extension;
    
public:
    
    string getName(){return name;}
    string getExtension(){return extension;}
    
    void setName(string newName){name = newName;}
    void setExtension(string newEx){extension = newEx;}
    
};

#endif /* File_hpp */
