//
//  Smartphone.hpp
//  Assignment8
//
//  Created by Danilo Mendes on 4/17/16.
//  Copyright © 2016 Danilo Mendes. All rights reserved.
//

#ifndef Smartphone_hpp
#define Smartphone_hpp

#include "DeviceOS.hpp"
#include "Computer.hpp"

class Smartphone : public DeviceOS {
    
    bool installed;
    Computer pc;
    
public:
    
    Smartphone(){installed=false;};
    
    Computer getComputer(){return pc;}
    void setComputer(Computer newPc){pc = newPc;};
    
    bool sync();
    bool isInstalled(){return installed;};
    void changeInstalled(){installed = !installed;};
    
    
};

#endif /* Smartphone_hpp */
