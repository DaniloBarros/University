/*
PROGRAM: FILE_NAME.CPP
Written by YOUR_NAME_AND_SURNAME_HERE
This program...
Last modification:
*/

/** DO NOT REMOVE THIS INCLUDE STATEMENT **/
#include "dummy_driver.h"
/******************************************/

/** You might need to add some headers here **/

/** DO NOT MODIFY FUNCTION SIGNATURE **/
double annual_pay(double payAmount, int payPeriods){
/**************************************/

    /** Implement the function **/

}


int main()
{
    
    /**                       DO NOT MODIFY UNDER THIS LINE
     * ***************************************************************************************/
    bool retval = test6(annual_pay);
    
    if(retval)
	return 0;
    else
	return 1;
}
