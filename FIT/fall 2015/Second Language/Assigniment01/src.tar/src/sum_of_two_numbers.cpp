/*
PROGRAM: FILE_NAME.CPP
Written by YOUR_NAME_AND_SURNAME_HERE
This program...
Last modification:
*/

/** DO NOT REMOVE THIS INCLUDE STATEMENT **/
#include "dummy_driver.h"
/******************************************/

/** You might need to add some headers here **/

/** DO NOT MODIFY FUNCTION SIGNATURE **/
int sum_of_two_numbers(int num1, int num2){
/**************************************/

    /** Implement the function **/

}

/**                       DO NOT MODIFY UNDER THIS LINE
 * ***************************************************************************************/
int main()
{
    
    bool retval = test1(sum_of_two_numbers);
    
    if(retval)
    	return 0;
    else
	return 1;
}
